# 猴博士速通 · 脚本工具

## generate_handout.js · 讲义生成器

把 Markdown 风格讲义转成 docx（猴博士原版讲义风格）。

### 前置依赖
```bash
npm install -g docx
```

### 用法
```bash
node generate_handout.js <讲义.md> <输出.docx> [科目] [章节]
```

### Markdown 规范

讲义必须按以下结构写，生成器才能正确解析：

```markdown
# 科目名（一级标题）
## 章名（二级标题）
### 套路名（三级标题）
普通段落，支持 **加粗** 高亮
- 列表项 1
- 列表项 2
| 表头 1 | 表头 2 |
|--------|--------|
| 内容   | 内容   |
```

### 输出排版
- 标题层级：H1 蓝色 36 半磅 / H2 蓝色 30 半磅 / H3 红色 26 半磅
- 表格：浅蓝表头 + 灰色细边框
- 页眉：🐒 猴博士速通 · 科目
- 页脚：章节 · 第 N 页
- 页边距：1 英寸
- 字体：微软雅黑

---

## generate_cheatsheet.js · 小抄 PDF 生成器

把核心知识点压成"塞笔袋小抄"——字号 3pt、行距 3pt、无边框的紧凑 PDF。

### 前置依赖
```bash
cd ~/.workbuddy/skills/houboshi-crash-course
npm install pdfkit
```

### 用法

```bash
node generate_cheatsheet.js <输出.pdf> <标题> <csv内容>
```

csv 内容格式：
- 每行一个知识点行
- 列用 `||` 分隔
- 换行用 `\n`（shell 里要转义）

### 排版铁律（不要改）

| 参数 | 数值 |
|------|------|
| 字号 | 3pt |
| 行距 | 固定 3pt |
| 页面 | A4 横向 |
| 边距 | 0 |
| 字体 | Helvetica |
| 颜色 | 纯黑 |

### 例子

```bash
node generate_cheatsheet.js out.pdf "高数第3章" "主题||踩分点||口诀
罗尔定理||三条件缺一不可||连续·可导·端点等
拉格朗日||构造辅助函数||f(b)-f(a)=f'(ξ)(b-a)
洛必达||0/0或∞/∞||lim f/g=lim f'/g'
泰勒||展到合适阶||f(x)=f(x₀)+f'(x₀)(x-x₀)+Rₙ"
```

### 集成到 skill 工作流

`SKILL.md` 小抄模式第 2 步默认调用方式。
