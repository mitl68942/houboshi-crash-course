#!/usr/bin/env node
/**
 * 猴博士速通 · 小抄 PDF 生成器 v3 · 中文版
 *
 * 排版铁律（不要改）：
 *   - 字号 3pt
 *   - 行距固定 3pt
 *   - 页面无边框、边距 0
 *   - 表格用纯文本 || 分隔
 *   - 字体：思源黑体 / 黑体（嵌入字体文件）
 *
 * 用法：
 *   node cheatsheet.js <输出路径.pdf> <标题> <csv内容>
 */
const fs = require('fs');
const path = require('path');
const PDFDocument = require('pdfkit');

// 找系统字体（按优先级）
function findChineseFont() {
  const candidates = [
    'C:\\Windows\\Fonts\\simhei.ttf',   // 黑体 (.ttf，PDFKit 友好)
    'C:\\Windows\\Fonts\\simsun.ttc',   // 宋体
    'C:\\Windows\\Fonts\\msyh.ttc',     // 微软雅黑 (.ttc，需拆分)
    '/System/Library/Fonts/PingFang.ttc', // macOS
    '/usr/share/fonts/truetype/wqy/wqy-microhei.ttc', // Linux
  ];
  for (const p of candidates) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

const [,, outPath, title = '小抄', csvStr = ''] = process.argv;
if (!outPath) {
  console.error('Usage: node cheatsheet.js <out.pdf> <title> <csv>');
  process.exit(1);
}

const fontPath = findChineseFont();
if (!fontPath) {
  console.error('❌ 找不到中文字体文件！');
  console.error('   请安装：思源黑体 / 微软雅黑 / 黑体');
  process.exit(1);
}
console.log('📝 使用字体：' + fontPath);

const doc = new PDFDocument({
  size: 'A4',
  layout: 'landscape',
  margins: { top: 0, bottom: 0, left: 0, right: 0 },
  info: { Title: title, Author: '猴博士速通' },
});

// 注册中文字体
doc.registerFont('cn', fontPath);
doc.registerFont('cn-bold', fontPath);

const stream = fs.createWriteStream(outPath);
doc.pipe(stream);

stream.on('finish', () => {
  const stat = fs.statSync(outPath);
  console.log('✅ 小抄已生成：' + outPath + ' (' + (stat.size / 1024).toFixed(1) + ' KB)');
  console.log('🐭 打印提示：A4 单面，缩到 1/4 纸大小塞笔袋。别让监考看见。');
});

doc.font('cn');

// 解析：每行拼成一整条文本，不分列
const lines = csvStr.split('\n')
  .map(line => line.trim())
  .filter(line => line.length > 0);

// 排版参数
const pageW = 842;       // A4 横向
const pageH = 595;
const fontSize = 3;
const lineHeight = 3;
const yStart = 1;

doc.fontSize(fontSize);
let y = yStart;
const maxY = pageH - 2;

lines.forEach((line, idx) => {
  if (y > maxY) {
    doc.addPage({
      size: 'A4', layout: 'landscape',
      margins: { top: 0, bottom: 0, left: 0, right: 0 }
    });
    y = yStart;
  }
  doc.font(idx === 0 ? 'cn-bold' : 'cn');
  doc.text(line, 0, y, {
    width: pageW,
    height: lineHeight,
    lineBreak: false,
    ellipsis: true,
  });
  y += lineHeight;
});

doc.end();
