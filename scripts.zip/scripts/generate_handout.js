#!/usr/bin/env node
/**
 * 猴博士速通讲义生成器
 * 把 Markdown 风格的讲义转成 docx
 *
 * 用法：
 *   node generate_handout.js <讲义markdown> <输出docx路径> [科目] [章节]
 *
 * 讲义 markdown 规范（用本 skill 生成的内容会自动符合）：
 *   # 一级标题（科目名）
 *   ## 二级标题（章名）
 *   ### 三级标题（套路名）
 *   普通段落
 *   - 列表项
 *   **加粗**
 *   | 表格 | 列 | 列 |
 *   |------|----|----|
 *   | a    | b  | c  |
 */

const fs = require('fs');
const path = require('path');
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, LevelFormat, HeadingLevel,
  BorderStyle, WidthType, ShadingType, PageNumber, PageBreak,
} = require('docx');

// ---- 解析 Markdown ----
function parseMarkdown(md) {
  const lines = md.split('\n');
  const blocks = [];
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    if (line.startsWith('### ')) {
      blocks.push({ type: 'h3', text: line.slice(4).trim() });
      i++;
    } else if (line.startsWith('## ')) {
      blocks.push({ type: 'h2', text: line.slice(3).trim() });
      i++;
    } else if (line.startsWith('# ')) {
      blocks.push({ type: 'h1', text: line.slice(2).trim() });
      i++;
    } else if (line.startsWith('|') && line.includes('|')) {
      // 表格
      const tableLines = [];
      while (i < lines.length && lines[i].startsWith('|') && lines[i].includes('|')) {
        tableLines.push(lines[i]);
        i++;
      }
      blocks.push({ type: 'table', rows: tableLines });
    } else if (line.startsWith('- ') || /^\d+\.\s/.test(line)) {
      // 列表
      const listItems = [];
      while (i < lines.length && (lines[i].startsWith('- ') || /^\d+\.\s/.test(lines[i]))) {
        listItems.push(lines[i].replace(/^-\s|^\d+\.\s/, '').trim());
        i++;
      }
      blocks.push({ type: 'list', items: listItems });
    } else if (line.trim() === '---' || line.trim() === '') {
      i++;
    } else {
      // 段落
      const paraLines = [];
      while (i < lines.length && lines[i].trim() !== '' && !lines[i].startsWith('#') && !lines[i].startsWith('|') && !lines[i].startsWith('-') && !/^\d+\.\s/.test(lines[i])) {
        paraLines.push(lines[i]);
        i++;
      }
      if (paraLines.length > 0) {
        blocks.push({ type: 'p', text: paraLines.join(' ').trim() });
      }
    }
  }
  return blocks;
}

// ---- 段落内 inline 样式（处理 **加粗**）----
function parseInline(text) {
  const runs = [];
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  for (const p of parts) {
    if (!p) continue;
    if (p.startsWith('**') && p.endsWith('**')) {
      runs.push(new TextRun({ text: p.slice(2, -2), bold: true, color: 'D13438' }));
    } else {
      runs.push(new TextRun({ text: p }));
    }
  }
  return runs;
}

// ---- 块 → docx elements ----
function blockToElements(blocks) {
  const elements = [];
  for (const b of blocks) {
    if (b.type === 'h1') {
      elements.push(new Paragraph({
        heading: HeadingLevel.HEADING_1,
        children: [new TextRun({ text: b.text, bold: true, size: 36, color: '1F4E79' })],
      }));
    } else if (b.type === 'h2') {
      elements.push(new Paragraph({
        heading: HeadingLevel.HEADING_2,
        children: [new TextRun({ text: b.text, bold: true, size: 30, color: '2E75B6' })],
      }));
    } else if (b.type === 'h3') {
      elements.push(new Paragraph({
        heading: HeadingLevel.HEADING_3,
        children: [new TextRun({ text: b.text, bold: true, size: 26, color: 'C00000' })],
      }));
    } else if (b.type === 'p') {
      elements.push(new Paragraph({
        children: parseInline(b.text),
        spacing: { after: 120 },
      }));
    } else if (b.type === 'list') {
      for (const item of b.items) {
        elements.push(new Paragraph({
          children: parseInline(item),
          bullet: { level: 0 },
          spacing: { after: 60 },
        }));
      }
    } else if (b.type === 'table') {
      elements.push(makeTable(b.rows));
    }
  }
  return elements;
}

function makeTable(rows) {
  // 过滤分隔行（|---|---|）
  const dataRows = rows.filter(r => !/^\|[\s-:|]+\|$/.test(r.trim()));
  const tableRows = dataRows.map((r, idx) => {
    const cells = r.split('|').slice(1, -1).map(c => c.trim());
    return new TableRow({
      children: cells.map(c => new TableCell({
        width: { size: 9360 / cells.length, type: WidthType.DXA },
        shading: idx === 0 ? { fill: 'D5E8F0', type: ShadingType.CLEAR } : undefined,
        borders: {
          top: { style: BorderStyle.SINGLE, size: 1, color: 'CCCCCC' },
          bottom: { style: BorderStyle.SINGLE, size: 1, color: 'CCCCCC' },
          left: { style: BorderStyle.SINGLE, size: 1, color: 'CCCCCC' },
          right: { style: BorderStyle.SINGLE, size: 1, color: 'CCCCCC' },
        },
        margins: { top: 80, bottom: 80, left: 120, right: 120 },
        children: [new Paragraph({
          children: [new TextRun({ text: c, bold: idx === 0 })],
        })],
      })),
    });
  });

  const colCount = dataRows[0].split('|').length - 2;
  return new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: Array(colCount).fill(9360 / colCount),
    rows: tableRows,
  });
}

// ---- 主流程 ----
function main() {
  const [,, mdPath, outPath, subject = '速通', chapter = '猴博士速通'] = process.argv;
  if (!mdPath || !outPath) {
    console.error('用法：node generate_handout.js <讲义.md> <输出.docx> [科目] [章节]');
    process.exit(1);
  }

  const md = fs.readFileSync(mdPath, 'utf-8');
  const blocks = parseMarkdown(md);
  const elements = blockToElements(blocks);

  const doc = new Document({
    creator: '猴博士速通 Skill',
    title: subject + ' · ' + chapter,
    styles: {
      default: { document: { run: { font: 'Microsoft YaHei', size: 22 } } },
      paragraphStyles: [
        { id: 'Heading1', name: 'Heading 1', basedOn: 'Normal', next: 'Normal', quickFormat: true,
          run: { size: 36, bold: true, font: 'Microsoft YaHei', color: '1F4E79' },
          paragraph: { spacing: { before: 360, after: 240 }, outlineLevel: 0 } },
        { id: 'Heading2', name: 'Heading 2', basedOn: 'Normal', next: 'Normal', quickFormat: true,
          run: { size: 30, bold: true, font: 'Microsoft YaHei', color: '2E75B6' },
          paragraph: { spacing: { before: 240, after: 180 }, outlineLevel: 1 } },
        { id: 'Heading3', name: 'Heading 3', basedOn: 'Normal', next: 'Normal', quickFormat: true,
          run: { size: 26, bold: true, font: 'Microsoft YaHei', color: 'C00000' },
          paragraph: { spacing: { before: 200, after: 140 }, outlineLevel: 2 } },
      ],
    },
    sections: [{
      properties: {
        page: {
          size: { width: 12240, height: 15840 },
          margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 },
        },
      },
      headers: {
        default: new Header({
          children: [new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [new TextRun({ text: '🐒 猴博士速通 · ' + subject, bold: true, size: 20, color: 'C00000' })],
          })],
        }),
      },
      footers: {
        default: new Footer({
          children: [new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({ text: chapter + ' · 第 ', size: 18, color: '808080' }),
              new TextRun({ children: [PageNumber.CURRENT], size: 18, color: '808080' }),
              new TextRun({ text: ' 页', size: 18, color: '808080' }),
            ],
          })],
        }),
      },
      children: elements,
    }],
  });

  Packer.toBuffer(doc).then(buf => {
    fs.writeFileSync(outPath, buf);
    console.log('✅ 讲义已生成：' + outPath + ' (' + (buf.length / 1024).toFixed(1) + ' KB)');
  });
}

main();
